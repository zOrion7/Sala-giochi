package com.makeitsimple.salagiochi.SpaceShooter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.makeitsimple.salagiochi.R;


public class Life {

    private Bitmap mBitmap;
    private int mX;
    private int mY;

    private int mScreenSizeX;
    private int mScreenSizeY;

    private final int OFFSET=100;

    Life(Context context, int screenSizeX, int screenSizeY, int distance){
        mScreenSizeX = screenSizeX;
        mScreenSizeY = screenSizeY;

        mBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.life);
        mBitmap = Bitmap.createScaledBitmap(mBitmap, mBitmap.getWidth() , mBitmap.getHeight() , false);

        mX =screenSizeX-OFFSET-distance*mBitmap.getWidth();
        mY =0;

    }


    public Bitmap getBitmap() {
        return mBitmap;
    }

    public int getX() {
        return mX;
    }

    public int getY() {
        return mY;
    }
}
