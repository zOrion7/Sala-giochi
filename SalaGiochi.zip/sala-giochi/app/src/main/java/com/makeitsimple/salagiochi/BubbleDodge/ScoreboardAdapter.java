package com.makeitsimple.salagiochi.BubbleDodge;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.makeitsimple.salagiochi.R;

import java.util.ArrayList;


public class ScoreboardAdapter extends RecyclerView.Adapter<ScoreboardAdapter.ExampleViewHolder> {
    private ArrayList<ScoreboardItem> itemList;

    public static class ExampleViewHolder extends RecyclerView.ViewHolder {
        public TextView mTextView1;
        public TextView mTextView2;

        public ExampleViewHolder(View itemView) {
            super(itemView);
            mTextView1 = itemView.findViewById(R.id.textView);
            mTextView2 = itemView.findViewById(R.id.textView2);
        }
    }

    public ScoreboardAdapter(ArrayList<ScoreboardItem> itemList) {
        this.itemList = itemList;
    }

    @Override
    public ExampleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.score_item, parent, false);
        ExampleViewHolder evh = new ExampleViewHolder(v);
        return evh;
    }

    @Override
    public void onBindViewHolder(ExampleViewHolder holder, int position) {
        ScoreboardItem currentItem = itemList.get(position);

        holder.mTextView1.setText(currentItem.getNickname());
        holder.mTextView2.setText(currentItem.getScore());
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }
}
