package com.makeitsimple.salagiochi.BubbleDodge;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.makeitsimple.salagiochi.Helpers.DBOpenHelper;
import com.makeitsimple.salagiochi.Helpers.ServerHelper;
import com.makeitsimple.salagiochi.R;

public class GameOver extends Activity implements View.OnClickListener {
    private Button buttonClassifica;
    private Button buttonHomepage;
    private Button buttonRiprova;
    private Integer score;
    private DBOpenHelper myDBOpenHelper;

    //Variabili temporanee per il DB
    private String nickname;
    private String gameID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_game_over);

        //Variabili temporanee per il DB
        nickname= "\"Vincenzo\"";
        gameID= "Gioco2";

        //DATABASE
        myDBOpenHelper= new DBOpenHelper(this);
        buttonClassifica = findViewById(R.id.buttonClassifica);
        buttonHomepage = findViewById(R.id.buttonHomepage);
        buttonRiprova = findViewById(R.id.buttonRiprova);
        TextView textViewPunteggio= findViewById(R.id.textViewPunteggio);
        buttonClassifica.setOnClickListener(this);
        buttonHomepage.setOnClickListener(this);
        buttonRiprova.setOnClickListener(this);
        Bundle bundle = getIntent().getExtras();
        if (bundle != null)
            score = bundle.getInt("score");
        textViewPunteggio.append(score.toString());
        //CARICAMENTO PUNTEGGIO SUL DB REMOTO
        ServerHelper.InviaDati(this, "nickname4", "10", "Gioco3");

        //CARICAMENTO PUNTEGGIO SUL DB LOCALE
        myDBOpenHelper.inviaDatiDB(nickname, gameID, score);
    }

    @Override
    public void onClick(View v) {
        if(v== buttonClassifica){
            Intent scoreboard= new Intent(this,Scoreboard.class);
            scoreboard.putExtra("score",score);
            startActivity(scoreboard);
        }else if(v== buttonHomepage){
            Intent homepage= new Intent(this, BubbleDodgeMain.class);
            startActivity(homepage);

        }else if(v== buttonRiprova){
            Intent riprova= new Intent(this, BubbleDodgeGameActivity.class);
            startActivity(riprova);
        }
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        myDBOpenHelper.close();
    }
}
