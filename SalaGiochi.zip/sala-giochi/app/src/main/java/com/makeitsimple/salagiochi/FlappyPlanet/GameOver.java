package com.makeitsimple.salagiochi.FlappyPlanet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.makeitsimple.salagiochi.BubbleDodge.BubbleDodgeMain;
import com.makeitsimple.salagiochi.Helpers.ConnectionHelper;
import com.makeitsimple.salagiochi.Helpers.DBOpenHelper;
import com.makeitsimple.salagiochi.Helpers.ServerHelper;
import com.makeitsimple.salagiochi.MainActivity;
import com.makeitsimple.salagiochi.R;
import com.makeitsimple.salagiochi.SpaceShooter.SpaceShooterMain;

public class GameOver extends AppCompatActivity {


    private Button buttonClassifica;
    private Button buttonMenu;
    private Button buttonRiprova;
    private TextView textPunteggio;

    private Integer punteggio;

    private String myGameName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over_flappyplanet);

        textPunteggio = findViewById(R.id.idTextScore);


        buttonClassifica = findViewById(R.id.idButtonClassifica);
        buttonMenu = findViewById(R.id.idButtonMenu);
        buttonRiprova = findViewById(R.id.idButtonRestart);


        Bundle bundle = getIntent().getExtras();
        if (bundle != null){
            punteggio = bundle.getInt("score");
            myGameName=bundle.getString("GameName");
        }

        textPunteggio.append(punteggio.toString());


        if(ConnectionHelper.ControlloConnessione(this)) {
            ServerHelper.InviaDati(this, "Ivano3",  "Gioco1",punteggio.toString());
        }
        DBOpenHelper db = new DBOpenHelper(this);
        db.inviaDatiDB("Ivano3","Gioco1",punteggio);

    }

    public void onRestart(View v){
        Intent restart = null;
        switch (myGameName){
            case "Gioco1":
                restart= new Intent(this, FlappyPlanet.class);
                break;
            case "Gioco2":
                restart= new Intent(this, BubbleDodgeMain.class);
                break;
            case "Gioco3":
                restart= new Intent(this, SpaceShooterMain.class);
                break;
            case "Gioco4":
                //restart= new Intent(this, );
                break;
        }
        startActivity(restart);
    }

    public void onScoreboard(View v){
        Intent scoreboard = new Intent(this,Scoreboard.class);
        scoreboard.putExtra("GameName",myGameName);
        startActivity(scoreboard);

    }
    public void onMenu(View v){
        Intent menu = new Intent(this, MainActivity.class);
        startActivity(menu);
    }
}
