package com.makeitsimple.salagiochi.BubbleDodge;


import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

import com.makeitsimple.salagiochi.R;

public class BubbleDodgeMain extends Activity implements View.OnClickListener {

    private Button buttonPlay;
    private Button buttonScore;
    private SeekBar mySeekBar;
    private int value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_bubble_dodge);
        buttonPlay= findViewById(R.id.buttonRiprova);
        buttonScore= findViewById(R.id.buttonHomepage);
        mySeekBar= findViewById(R.id.seekBarSensore);
        //Listener
        buttonScore.setOnClickListener(this);
        buttonPlay.setOnClickListener(this);
        //Seekbar
        mySeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                value=progress;
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    @Override
    public void onClick(View v) {
        if(v==buttonPlay){
            Intent startGame= new Intent(this, BubbleDodgeGameActivity.class);
            //Passo il valore della seekbar all'ultimo rilevamento
            startGame.putExtra("value",value);
            startActivity(startGame);
        }
        if(v==buttonScore){
            Intent scoreboard= new Intent(this,Scoreboard.class);
            startActivity(scoreboard);
        }
    }
}
