package com.makeitsimple.salagiochi.SpaceShooter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.makeitsimple.salagiochi.R;

import java.util.Random;


public class Star {

    private Bitmap mBitmap;
    private int mX;
    private int mY;
    private int mMaxX;
    private int mSpeed;
    private int mScreenSizeX;
    private int mScreenSizeY;
    private final int STAR_SPEED=7;
    private int[] mStars = new int[]{R.drawable.star_1, R.drawable.star_2, R.drawable.star_3};

    Star(Context context, int screenSizeX, int screenSizeY, boolean randomY){
        mScreenSizeX = screenSizeX;
        mScreenSizeY = screenSizeY;

        Random random = new Random();
        mBitmap = BitmapFactory.decodeResource(context.getResources(), mStars[random.nextInt(3)]);

        float mStarScaleFactor = (float)(random.nextInt(mStars.length) + 1)/mStars.length;
        int scaledWidth,scaledHeight;
        scaledWidth= (int)(mBitmap.getWidth() * mStarScaleFactor);
        scaledHeight= (int)(mBitmap.getHeight() * mStarScaleFactor);

        mBitmap = Bitmap.createScaledBitmap(mBitmap, scaledWidth, scaledHeight, false);


        mMaxX = screenSizeX - mBitmap.getWidth();

        mSpeed = random.nextInt(STAR_SPEED) + 1;

        mX = random.nextInt(mMaxX);
        if (randomY){
            mY = random.nextInt(mScreenSizeY);
        }else{
            mY = 0 - mBitmap.getHeight();
        }

    }

    public void update(){
        mY += mSpeed;
    }

    public Bitmap getBitmap() {
        return mBitmap;
    }

    public int getX() {
        return mX;
    }

    public int getY() {
        return mY;
    }
}
