package com.makeitsimple.salagiochi.SpaceShooter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import com.makeitsimple.salagiochi.R;

import java.util.ArrayList;


public class Player {

    private Bitmap mBitmap;

    private int mX;
    private int mY;

    private int mMaxX;
    private int mMinX;
    private int mMargin = 16;
    private boolean mIsSteerLeft, mIsSteerRight;
    private float mSteerSpeed;
    private Rect mCollision;
    private ArrayList<Laser> mLasers;
    private Shield  mShield;
    private SoundPlayer mSoundPlayer;
    private Context mContext;
    private int mScreenSizeX, mScreenSizeY;
    private final int SPEED=10;

    Player(Context context, int screenSizeX, int screenSizeY, SoundPlayer soundPlayer) {
        mScreenSizeX = screenSizeX;
        mScreenSizeY = screenSizeY;
        mContext = context;
        mBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.player_ship1_red);
        int scaledWidth,scaledHeight;
        scaledWidth= (int) (mBitmap.getWidth() * GameView.IMAGE_SCALING_FACTOR);
        scaledHeight= (int) (mBitmap.getHeight() * GameView.IMAGE_SCALING_FACTOR);

        mBitmap = Bitmap.createScaledBitmap(mBitmap, scaledWidth, scaledHeight, false);
        mMaxX = screenSizeX - mBitmap.getWidth();
        mMinX = 0;
        mX = screenSizeX/2 - mBitmap.getWidth()/2;
        mY = screenSizeY - mBitmap.getHeight() - mMargin;
        mLasers = new ArrayList<>();
        mSoundPlayer = soundPlayer;
        mCollision = new Rect(mX, mY, mX + mBitmap.getWidth(), mY + mBitmap.getHeight());
    }

    public void update(){
        if (mIsSteerLeft){
            mX -= SPEED * mSteerSpeed;
            if (mX<mMinX){
                mX = mMinX;
            }
        }else if (mIsSteerRight){
            mX += SPEED * mSteerSpeed;
            if (mX>mMaxX){
                mX = mMaxX;
            }
        }

        mCollision.left = mX;
        mCollision.top = mY;
        mCollision.right = mX + mBitmap.getWidth();
        mCollision.bottom = mY + mBitmap.getHeight();

        for (Laser l : mLasers) l.update();
        boolean deleting = true;
        while (deleting) {
            if (mLasers.size() != 0) {
                if (mLasers.get(0).getY() < 0) {
                    mLasers.remove(0);
                }
            }
            if (mLasers.size() == 0 || mLasers.get(0).getY() >= 0) {
                deleting = false;
            }
        }
        if(mShield!=null){
            if(mShield.getY()>0)mShield.update(mX, mY, mBitmap);
        }
    }

    ArrayList<Laser> getLasers() {
        return mLasers;
    }

    Shield getShield() {
        return mShield;
    }

    void fire(){
        mLasers.add(new Laser(mContext, mScreenSizeX, mScreenSizeY, mX, mY, mBitmap));
        mSoundPlayer.playLaser();
    }
    void fire(int offset){
        mLasers.add(new Laser(mContext, mScreenSizeX, mScreenSizeY, mX-offset, mY, mBitmap));
        fire();
        mLasers.add(new Laser(mContext, mScreenSizeX, mScreenSizeY, mX+offset, mY, mBitmap));
    }
    void shield(){
        mShield=new Shield(mContext, mScreenSizeX, mScreenSizeY, mX, mY, mBitmap);
        mSoundPlayer.playShield();
    }
    void upgrade(){
        mSoundPlayer.playUpgrade();
    }

    Rect getCollision() {
        return mCollision;
    }

    void steerRight(float speed){
        mIsSteerLeft = false;
        mIsSteerRight = true;
        mSteerSpeed = Math.abs(speed);
    }

    void steerLeft(float speed){
        mIsSteerRight = false;
        mIsSteerLeft = true;
        mSteerSpeed = Math.abs(speed);
    }

    void stay(){
        mIsSteerLeft = false;
        mIsSteerRight = false;
        mSteerSpeed = 0;
    }

    public Bitmap getBitmap() {
        return mBitmap;
    }

    public int getX() {
        return mX;
    }

    public int getY() {
        return mY;
    }

}
