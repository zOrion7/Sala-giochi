package com.makeitsimple.salagiochi.BubbleDodge;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;

import com.makeitsimple.salagiochi.R;

public class Player implements SensorEventListener{
    //coordinates
    private int x;
    private int y;
    //sensor
    SensorManager sensorManager;
    private int sensorX;
    private int sensorCustomValue;
    //jump
    private boolean jump;
    //screen bound
    private int minY,maxY;
    private int minX,maxX;

    private Rect detectCollision;

    //animation
    private Bitmap idleState;
    private Animation idle;
    private Animation walkRight;
    private Animation walkLeft;
    private Animation jumpLeft;
    private Animation jumpRight;

    private AnimationManager animationManager;

    public Player(Context context, int screenX, int screenY, int value){
        idleState= BitmapFactory.decodeResource(context.getResources(),R.drawable.aliengreen);
        x= screenX/2;
        y= screenY;
        maxY= screenY - idleState.getHeight();
        maxX= screenX - idleState.getWidth();
        minX= 0;
        minY= 0;
        //Sensore
        sensorCustomValue= value;
        sensorManager= (SensorManager)
                context.getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            sensorManager.registerListener((SensorEventListener) this,
                    sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                    SensorManager.SENSOR_DELAY_GAME);
        }

        detectCollision= new Rect(x, y, idleState.getWidth(),idleState.getHeight());

        Bitmap walkR1= BitmapFactory.decodeResource(context.getResources(),R.drawable.aliengreen_walk1);
        Bitmap walkR2= BitmapFactory.decodeResource(context.getResources(),R.drawable.aliengreen_walk2);
        Bitmap walkL1= BitmapFactory.decodeResource(context.getResources(),R.drawable.aliengreen_walk1_left);
        Bitmap walkL2= BitmapFactory.decodeResource(context.getResources(),R.drawable.aliengreen_walk2_left);
        Bitmap jumpL= BitmapFactory.decodeResource(context.getResources(),R.drawable.alien_jump_left);
        Bitmap jumpR= BitmapFactory.decodeResource(context.getResources(),R.drawable.alien_jump_right);

        idle= new Animation(new Bitmap[]{idleState},2);
        walkRight= new Animation(new Bitmap[]{walkR1,walkR2},0.5f);
        walkLeft= new Animation(new Bitmap[]{walkL1,walkL2},0.5f);
        jumpLeft= new Animation(new Bitmap[]{jumpL},2);
        jumpRight= new Animation(new Bitmap[]{jumpR},2);
        animationManager= new AnimationManager(new Animation[]{idle, walkRight, walkLeft, jumpLeft, jumpRight});
    }

    public void draw(Canvas canvas){
        animationManager.draw(canvas,detectCollision);
    }

    public void update(){
        float oldLeft= detectCollision.left;
        int state=0;
        x+=sensorX;
        jumping();

        //Bounds
        if(x<=minX) x= minX;
        if(x>=maxX) x= maxX;
        if(y<=minY) y= minY;
        if(y>=maxY) y= maxY;

        detectCollision.left = x;
        detectCollision.top = y;
        detectCollision.right = x + idleState.getWidth();
        detectCollision.bottom = y + idleState.getHeight();

        //Modifichiamo lo stato dell'animazione in base alla posizione del rect collegato al bitmap
        if(detectCollision.left-oldLeft>2){
            state= 1;
            if(jump)state= 4;
        }
        else if(detectCollision.left-oldLeft<-2){
            state= 2;
            if(jump)state= 3;
        }
        animationManager.playAnim(state);
        animationManager.update();
    }

    private void jumping() {
        int speed=30;
        if(jump){
            Log.d("JUMP", "DIO CANE : Y"+y+" MIN Y : "+minY);
            y-=speed;
            Log.d("JUMP", "SPEED : "+speed);
            if(y<=100){
                Log.d("JUMP", "DIOCANE SONO ARRIVATO ALLA FINE DEL SALTO, ORA DOVREI SCENDERE : Y"+y);
                jump=false;
            }
        }else y+=40;
    }

    @Override
    public void onSensorChanged(SensorEvent event){
        sensorX= (int)event.values[1]*(8+sensorCustomValue);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {    }

    //Setter
    public void setJump(boolean jump) {
        this.jump = jump;
    }
    //Getters
    public Rect getDetectCollision() {  return detectCollision; }




}
