package com.makeitsimple.salagiochi.FlappyPlanet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.Toast;

import com.makeitsimple.salagiochi.Helpers.DBOpenHelper;
import com.makeitsimple.salagiochi.Helpers.ServerHelper;
import com.makeitsimple.salagiochi.Helpers.TableHelper;
import com.makeitsimple.salagiochi.R;

public class Scoreboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_scoreboard_flappyplanet);

        //TextView classificaSingolo = findViewById(R.id.textViewClassificaFlappy);

        TableLayout tableSingle = findViewById(R.id.idTableSingleFlappyPlanet);
        TableLayout tableGlobal = findViewById(R.id.idTableGlobalFlappyPlanet);
        DBOpenHelper db = new DBOpenHelper(this);

         Cursor cursorSingle = db.getGameScoreboard("Gioco1");
        TableHelper.CreaTabella(this,cursorSingle,tableSingle);

       Cursor cursorGlobal = db.getGlobalScoreboard();

        //per vedere i punteggi degli altri giocatori e per il calcolo del GLOBAL.
        ServerHelper.UpdateClassificaGlobale(this);



        //TableHelper.CreaTabella(this,cursorGlobal,tableSingle);


    }

}
