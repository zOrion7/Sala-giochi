package com.makeitsimple.salagiochi.BubbleDodge;

public class ScoreboardItem {
    private String Nickname;
    private String Score;

    public ScoreboardItem(String Nickname, String Score) {
        this.Nickname= Nickname;
        this.Score= Score;
    }

    public String getNickname() {
        return Nickname;
    }

    public String getScore() {
        return Score;
    }
}
