package com.makeitsimple.salagiochi.SpaceShooter;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.util.Log;

import com.makeitsimple.salagiochi.R;


public class SoundPlayer implements Runnable {

    private Thread mSoundThread;
    private volatile boolean mIsPlaying;
    private SoundPool mSoundPool;
    private int mExplodeId, mLaserId, mCrashId, mShieldId,mUpgradeId;
    private boolean mIsLaserPlaying, mIsExplodePlaying, mIsCrashPlaying, mIsShieldPlaying, mIsUpgradePlaying;
    private float mVolume=0.5f;
    SoundPlayer(Context context){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            mSoundPool = new SoundPool.Builder()
                    .setMaxStreams(10)
                    .setAudioAttributes(attributes)
                    .build();
        } else {
            mSoundPool = new SoundPool(10, AudioManager.STREAM_MUSIC, 1);
        }
        mExplodeId = mSoundPool.load(context, R.raw.rock_explode_1, 1);
        mLaserId = mSoundPool.load(context, R.raw.laser_1, 1);
        mCrashId = mSoundPool.load(context, R.raw.rock_explode_2, 1);
        mShieldId = mSoundPool.load(context, R.raw.shield1, 1);
        mUpgradeId = mSoundPool.load(context, R.raw.upgrade, 1);
    }

    @Override
    public void run() {
        while (mIsPlaying){
            if (mIsLaserPlaying){
                mSoundPool.play(mLaserId, mVolume, mVolume, 1, 0, 1f);
                mIsLaserPlaying = false;
            }

            if (mIsUpgradePlaying){
                mSoundPool.play(mUpgradeId, mVolume, mVolume, 1, 0, 1f);
                mIsUpgradePlaying = false;
            }

            if (mIsExplodePlaying){
                mSoundPool.play(mExplodeId, mVolume, mVolume, 1, 0, 1f);
                mIsExplodePlaying = false;
            }

            if (mIsCrashPlaying){
                mSoundPool.play(mCrashId, mVolume, mVolume, 1, 0, 1f);
                mIsCrashPlaying = false;
            }
            if (mIsShieldPlaying){
                mSoundPool.play(mShieldId, mVolume, mVolume, 1, 0, 1f);
                mIsShieldPlaying = false;
            }
        }
    }

    void playCrash(){
        mIsCrashPlaying = true;
    }

    void playLaser(){
        mIsLaserPlaying = true;
    }

    void playExplode(){
        mIsExplodePlaying = true;
    }

    void playShield(){
        mIsShieldPlaying = true;
    }

    void playUpgrade(){
        mIsUpgradePlaying = true;
    }

    void resume(){
        mIsPlaying = true;
        mSoundThread = new Thread(this);
        mSoundThread.start();
    }

    void pause() throws InterruptedException {
        Log.d("GameThread", "Sound");
        mIsPlaying = false;
        mSoundThread.join();
    }
    void destroy(){
        mSoundPool.unload(mCrashId);
        mSoundPool.unload(mExplodeId);
        mSoundPool.unload(mLaserId);
        mSoundPool.unload(mShieldId);
        mSoundPool.unload(mUpgradeId);
        mSoundPool.release();
    }
}
