package com.makeitsimple.salagiochi.BubbleDodge;


import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.makeitsimple.salagiochi.Helpers.DBOpenHelper;
import com.makeitsimple.salagiochi.R;

import java.util.ArrayList;


public class Scoreboard extends Activity {
    private DBOpenHelper myDBOpenHelper;
    private TextView score;
    private TextView nickname;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scoreboard);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        //singolo = findViewById(R.id.idTextSingolo);
        //globale = findViewById(R.id.idTextGlobale);
        nickname= findViewById(R.id.textView);
        score= findViewById(R.id.textView2);

        ArrayList<ScoreboardItem> scoreboardList = new ArrayList<>();
        scoreboardList.add(new ScoreboardItem("Line 1", "Line 2"));
        scoreboardList.add(new ScoreboardItem("Line 312", "Line yr"));
        scoreboardList.add(new ScoreboardItem("Line 424", "Line 645"));
        scoreboardList.add(new ScoreboardItem("Line 54", "Line 543"));
        scoreboardList.add(new ScoreboardItem("Line 424", "Line 645"));
        scoreboardList.add(new ScoreboardItem("Line 54", "Line 543"));
        scoreboardList.add(new ScoreboardItem("Line 424", "Line 645"));
        scoreboardList.add(new ScoreboardItem("Line 54", "Line 543"));
        scoreboardList.add(new ScoreboardItem("Line 424", "Line 645"));
        scoreboardList.add(new ScoreboardItem("Line 54", "Line 543"));
        scoreboardList.add(new ScoreboardItem("Line 424", "Line 645"));
        scoreboardList.add(new ScoreboardItem("Line 54", "Line 543"));
        scoreboardList.add(new ScoreboardItem("Line 424", "Line 645"));
        scoreboardList.add(new ScoreboardItem("Line 54", "Line 543"));
        scoreboardList.add(new ScoreboardItem("Line 424", "Line 645"));
        scoreboardList.add(new ScoreboardItem("Line 54", "Line 543"));



        recyclerView= findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        layoutManager= new LinearLayoutManager(this);
        adapter= new ScoreboardAdapter(scoreboardList);

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        //DB LOCALE
        myDBOpenHelper = new DBOpenHelper(this);

        /*Cursor cursor= myDBOpenHelper.getGameScoreboard("Gioco2");
        if(cursor.getCount()!=0){
            while(cursor.moveToNext()){
                nickname.append(cursor.getString(0)+"\t");
                score.append(cursor.getString(1)+"\n");
            }
        }*/
        //DB REMOTO
        //ServerHelper.ClassificaSingolo(this,"Gioco1",singolo);
        //ServerHelper.ClassificaGlobale(this,globale);
    }
}
