package com.makeitsimple.salagiochi.SpaceShooter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import com.makeitsimple.salagiochi.R;


public class Laser {

    private Bitmap mBitmap;
    private int mX;
    private int mY;
    private Rect mCollision;
    private int mScreenSizeX;
    private int mScreenSizeY;
    private final int OFFSET =10;

    Laser(Context context, int screenSizeX, int screenSizeY, int spaceShipX, int spaceShipY, Bitmap spaceShip){
        mScreenSizeX = screenSizeX;
        mScreenSizeY = screenSizeY;
        mBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.space_missiles_006);
        int scaledWidth,scaledHeight;
        scaledWidth= (int) (mBitmap.getWidth() * GameView.IMAGE_SCALING_FACTOR);
        scaledHeight= (int) (mBitmap.getHeight() * GameView.IMAGE_SCALING_FACTOR);
        mBitmap = Bitmap.createScaledBitmap(mBitmap, scaledWidth, scaledHeight, false);
        mX = spaceShipX + spaceShip.getWidth()/2 - mBitmap.getWidth()/2;
        mY = spaceShipY - mBitmap.getHeight() - OFFSET;
        mCollision = new Rect(mX, mY, mX + mBitmap.getWidth(), mY + mBitmap.getHeight());
    }

    public void update(){
        mY -= mBitmap.getHeight() - OFFSET;
        mCollision.left = mX;
        mCollision.top = mY;
        mCollision.right = mX + mBitmap.getWidth();
        mCollision.bottom = mY + mBitmap.getHeight();
    }

    Rect getCollision() {
        return mCollision;
    }

    void destroy(){
        mY = 0 - mBitmap.getHeight();
    }

    public Bitmap getBitmap() {
        return mBitmap;
    }

    public int getX() {
        return mX;
    }

    public int getY() {
        return mY;
    }
}
