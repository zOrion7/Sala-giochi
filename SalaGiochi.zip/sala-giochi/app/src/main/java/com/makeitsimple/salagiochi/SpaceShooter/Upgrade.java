package com.makeitsimple.salagiochi.SpaceShooter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import com.makeitsimple.salagiochi.R;

import java.util.Random;


public class Upgrade {

    private Bitmap mBitmap;
    private int mX;
    private int mY;
    private int mSpeed;
    private Rect mCollision;


    private int mUpgradeSelected;
    private int mScreenSizeX;
    private int mScreenSizeY;
    private final int UPGRADE_SPEED=4;
    private int[] mUpgrade = new int[]{R.drawable.upgrade_scudo, R.drawable.upgrade_missile, R.drawable.upgrade_velocita};

    Upgrade(Context context, int screenSizeX, int screenSizeY){
        mScreenSizeX = screenSizeX;
        mScreenSizeY = screenSizeY;
        Random random = new Random();
        mUpgradeSelected=mUpgrade[random.nextInt(mUpgrade.length)];
        mBitmap = BitmapFactory.decodeResource(context.getResources(), mUpgradeSelected);
        mBitmap = Bitmap.createScaledBitmap(mBitmap, mBitmap.getWidth() , mBitmap.getHeight() , false);



        mSpeed = random.nextInt(UPGRADE_SPEED) + 1;

        mX = (random.nextInt(mScreenSizeX- mBitmap.getWidth())+ 1);
        mY = 0 - mBitmap.getHeight();
        mCollision = new Rect(mX, mY, mX + mBitmap.getWidth(), mY + mBitmap.getHeight());


    }

    public void update(){
        mY += mSpeed*UPGRADE_SPEED;
        mCollision.left = mX;
        mCollision.top = mY;
        mCollision.right = mX + mBitmap.getWidth();
        mCollision.bottom = mY + mBitmap.getHeight();
    }
    Rect getCollision() {
        return mCollision;
    }

    void destroy() {
        mY = mScreenSizeY + 1;
    }

    public Bitmap getBitmap() {
        return mBitmap;
    }

    public int getX() {
        return mX;
    }

    public int getY() {
        return mY;
    }

    int getCurrentUpgrade() {
        return mUpgradeSelected;
    }
}
